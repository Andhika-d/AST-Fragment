package com.example.projectfragment;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SharedViewModel extends ViewModel {
    private final MutableLiveData<List<String>> allSongs = new MutableLiveData<>();
    private final MutableLiveData<List<String>> favoriteSongs = new MutableLiveData<>(new ArrayList<>());

    public SharedViewModel() {
        // Contoh daftar lagu
        List<String> songs = Arrays.asList("SZA - Nobody Gets Me", "One Direction - Night Changes", "James Arthur, Annie-Marie - Rewrite The Stars", "Arctic Monkeys - I Wanna Be Yours", "SZA - Saturn");
        allSongs.setValue(songs);
    }

    public LiveData<List<String>> getAllSongs() {
        return allSongs;
    }

    public LiveData<List<String>> getFavoriteSongs() {
        return favoriteSongs;
    }

    public void addFavorite(String song) {
        List<String> currentFavorites = favoriteSongs.getValue();
        if (!currentFavorites.contains(song)) {
            currentFavorites.add(song);
            favoriteSongs.setValue(currentFavorites);
        }
    }

    public void removeFavorite(String song) {
        List<String> currentFavorites = favoriteSongs.getValue();
        if (currentFavorites.contains(song)) {
            currentFavorites.remove(song);
            favoriteSongs.setValue(currentFavorites);
        }
    }
}


