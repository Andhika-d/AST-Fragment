package com.example.projectfragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class FragmentB extends Fragment {
    private SharedViewModel sharedViewModel;
    private RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_b, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Tambahkan fungsi tombol kembali
        Button buttonBack = view.findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(v -> Navigation.findNavController(v).navigate(R.id.action_fragmentB_to_fragmentA));

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Lagu Favorit");
        }

        sharedViewModel.getFavoriteSongs().observe(getViewLifecycleOwner(), songs -> {
            FavoriteSongsAdapter adapter = new FavoriteSongsAdapter(songs, song -> {
                sharedViewModel.removeFavorite(song);
                Toast.makeText(getContext(), "Lagu dihapus dari favorit", Toast.LENGTH_SHORT).show();
            });
            recyclerView.setAdapter(adapter);
        });
        }

}


