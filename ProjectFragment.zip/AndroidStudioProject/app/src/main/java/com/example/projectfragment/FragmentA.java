package com.example.projectfragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class FragmentA extends Fragment {
    private SharedViewModel sharedViewModel;
    private RecyclerView recyclerView;
    private SongsAdapter adapter;
    private EditText searchEditText;
    private List<String> allSongsList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_a, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        searchEditText = view.findViewById(R.id.searchEditText);
        Button goToFavoritesButton = view.findViewById(R.id.buttonGoToFavorites);
        goToFavoritesButton.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.action_fragmentA_to_fragmentB));
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        // Mengubah judul toolbar
        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Daftar Lagu");
        }

        sharedViewModel.getAllSongs().observe(getViewLifecycleOwner(), songs -> {
            allSongsList.clear();
            allSongsList.addAll(songs); // Menambahkan lagu ke daftar allSongsList
            adapter = new SongsAdapter(songs, song -> {
                sharedViewModel.addFavorite(song);
                Toast.makeText(getContext(), "Lagu ditambahkan ke favorit", Toast.LENGTH_SHORT).show();
            });
            recyclerView.setAdapter(adapter);
        });

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void filter(String text) {
        List<String> filteredList = new ArrayList<>();
        for (String song : allSongsList) {
            if (song.toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(song);
            }
        }
        adapter.filterList(filteredList);
    }
}
