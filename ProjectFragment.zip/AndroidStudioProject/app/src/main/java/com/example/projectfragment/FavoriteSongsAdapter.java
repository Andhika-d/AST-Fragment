package com.example.projectfragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FavoriteSongsAdapter extends RecyclerView.Adapter<FavoriteSongsAdapter.ViewHolder> {
    private List<String> favoriteSongs;
    private OnRemoveClickListener listener;

    public FavoriteSongsAdapter(List<String> favoriteSongs, OnRemoveClickListener listener) {
        this.favoriteSongs = favoriteSongs;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.favorite_song_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String song = favoriteSongs.get(position);
        holder.textView.setText(song);
        holder.removeButton.setOnClickListener(v -> listener.onRemoveClick(song));
    }

    @Override
    public int getItemCount() {
        return favoriteSongs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        Button removeButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            removeButton = itemView.findViewById(R.id.removeButton);
        }
    }

    public interface OnRemoveClickListener {
        void onRemoveClick(String song);
    }
}

